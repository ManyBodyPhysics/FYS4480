This IPython notebook IMSRG.ipynb does not require any additional
programs.
