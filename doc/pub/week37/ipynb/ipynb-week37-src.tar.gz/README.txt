This IPython notebook week37.ipynb does not require any additional
programs.
