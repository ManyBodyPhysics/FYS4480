This IPython notebook quantumcomputing.ipynb does not require any additional
programs.
