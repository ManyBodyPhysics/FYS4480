This IPython notebook week41.ipynb does not require any additional
programs.
