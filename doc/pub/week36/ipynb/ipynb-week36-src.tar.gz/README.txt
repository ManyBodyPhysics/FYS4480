This IPython notebook week36.ipynb does not require any additional
programs.
