This IPython notebook week44.ipynb does not require any additional
programs.
