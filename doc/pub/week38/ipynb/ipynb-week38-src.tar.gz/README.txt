This IPython notebook week38.ipynb does not require any additional
programs.
