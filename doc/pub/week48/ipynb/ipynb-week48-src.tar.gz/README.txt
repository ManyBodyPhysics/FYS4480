This IPython notebook week48.ipynb does not require any additional
programs.
