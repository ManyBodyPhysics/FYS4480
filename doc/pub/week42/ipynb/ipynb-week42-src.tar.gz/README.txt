This IPython notebook week42.ipynb does not require any additional
programs.
