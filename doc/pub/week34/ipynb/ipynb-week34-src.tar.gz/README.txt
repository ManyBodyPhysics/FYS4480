This IPython notebook week34.ipynb does not require any additional
programs.
