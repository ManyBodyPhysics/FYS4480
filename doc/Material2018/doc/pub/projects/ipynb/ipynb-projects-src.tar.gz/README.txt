This IPython notebook projects.ipynb does not require any additional
programs.
